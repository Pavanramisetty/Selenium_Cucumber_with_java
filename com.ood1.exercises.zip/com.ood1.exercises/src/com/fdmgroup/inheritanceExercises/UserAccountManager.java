package com.fdmgroup.inheritanceExercises;

import java.util.ArrayList;

public class UserAccountManager {

	ArrayList<UserAccount> accountList = new ArrayList<>();

    public static void addUser(UserAccount user) {
    	System.out.println("add user");
    }
    
    public static boolean login(String username, String password) {
    	return false;
    }
}
