package com.fdmgroup.inheritanceExercises;

public class CustomerUser extends UserAccount {


	public CustomerUser(String username, String fullName) {
		super(username, fullName);
	}

	public static void accesssWebsite() {
		System.out.println("Accessing website from the custmer side");
	}
}
