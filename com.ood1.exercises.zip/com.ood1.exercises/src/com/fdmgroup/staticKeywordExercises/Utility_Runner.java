package com.fdmgroup.staticKeywordExercises;

public class Utility_Runner {

	public static void main(String[] args) {
	    System.out.println(EnergyMatterCalculator.energyToMatter(100));
	    System.out.println(EnergyMatterCalculator.matterToEnergy(200));
	}

}
