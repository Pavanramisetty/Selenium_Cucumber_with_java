package com.ecommerce.data;

public class DataFile {
	public static String homePageURL = "https://www.amazon.ca/";
	public static String loginPageTitle = "Amazon Sign In";
	public static String username = "pavan.ramisetty91@gmail.com";
	public static String user = "Hello, Lavanya";
	public static String password = "Dream@143";
	public static String searchItem = "amazonfiretv";
	//public static String selectedItem = "Amazon Fire TV 50\" 4-Series 4K UHD smart TV";
	public static String selectedItem = "Insignia 58\" 4K UHD HDR LCD Smart TV (NS-58F301CA22) - Fire TV Edition - 2021";
	public static String inStock = "In Stock";
	public static String changeItems = "3";
	public static String initialItems = "1";
	public static String cartIsZero =  "0";
	public static String addressVerify = "address";
	public static String fullname = "Changed Full name";
    }

